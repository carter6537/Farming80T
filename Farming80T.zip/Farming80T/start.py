#IMPORTS
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from datetime import datetime
import time
import json

#SET UP OPTIONS FOR BROWSER
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_argument('--ignore-ssl-errors=yes')
chromeOptions.add_argument('--ignore-certificate-errors')
chromeOptions.add_argument('--mute-audio')
chromeOptions.add_argument('--disable-blink-features=AutomationControlled') #REMOVES FLAG BEFORE IT CAN BE DETECTED
chrome_options.add_argument('--headless') #COMMENT THIS OUT FOR TESTING

lib = {
    "hanzyolo" : "carter6537",
    "hanstonks" : "carter6537",
    "testpy" : "testpy"
}

for acc in lib:
    ACC_NAME = acc
    ACC_PASS = lib[acc]

    #OPENS KRUNKER AND WAITS TO LOAD
    browser = webdriver.Chrome("./chromedriver", options=chromeOptions)
    browser.get("https://krunker.io")
    time.sleep(10) # seconds

    #ACCEPTS COOKIES
    browser.find_element(By.ID, "onetrust-accept-btn-handler").click()
    browser.execute_script("clearPops()") #remove pop ups

    #LOGIN
    browser.execute_script("showWindow(5)")
    usernameInput = browser.find_element(By.ID, "accName")
    passwordInput = browser.find_element(By.ID, "accPass")
    usernameInput.send_keys(ACC_NAME)
    passwordInput.send_keys(ACC_PASS)
    browser.execute_script("loginAcc()")
    time.sleep(5)
    browser.execute_script("clearPops()") #remove pop ups

    #CLAIM KR
    browser.execute_script("showWindow(14)") #opens the shop tab
    browser.execute_script("windows[13].switchTab(1)") #switches tab to spins page
    browser.execute_script("claimReward()") #starts free kr

    #WAIT TO SPIN
    time.sleep(80)
    browser.execute_script("clearPops()")
    browser.find_element(By.ID, "spinButton").click()
    time.sleep(10)

    win = browser.find_element(By.ID, "spinItemName").get_attribute("innerHTML")
    now = datetime.now()

    results = {
        "username" : ACC_NAME,
        "time" : now.strftime("%d/%m/%Y %H:%M:%S"),
        "won kr" : win
    }
    print(results)

    with open("history.json", "r") as json_file:
        data = json.load(json_file)
    data.append(results)
    with open("history.json", "w") as json_file:
        json.dump(data, json_file)

    browser.quit()