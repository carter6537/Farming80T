# import json
# with open("history.json", "r+") as json_file:
#     data = json.load(json_file)
#     print(data)

# with open("history.txt", "a") as doc:
# doc = open("history.txt", "a")
# doc.write("Hello World!")
# doc.close()

# lib = {
#     "testpy1" : "testpy"
# }

# for acc in lib:
#     ACC_NAME = acc
#     ACC_PASS = lib[acc]

# old scripts
# WAIT FOR AD TO FINISH THEN SPIN AND WAIT
# driver.execute_async_script(""
#     console.log = function(message){
#         if(message === "AD REMOVED")
#             browser.execute_script("clearPops()")
#             browser.execute_script("document.getElementById('spinButton').click()")
#             time.sleep(10)
#     };
# "")
# def check():
#     msg = browser.get_log('browser')
#     if(msg == "AD REMOVED"):
#         browser.execute_script("clearPops()")
#         browser.execute_script("document.getElementById('spinButton').click()")
#         time.sleep(10)
#         return True
#     else:
#         return False
# while (check() == False):
#     check()

#ACCEPTS COOKIES
# WebDriverWait(browser, 50).until(
#     lambda x: x.find_element(By.ID, "onetrust-accept-btn-handler")
# ).click()